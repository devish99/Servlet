package com.Connect;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

//import com.Connect.DBCon;
//import com.Connect.EmployeeBean;

public class EmployeeDAO {
	public boolean empInsert(EmployeeBean eb) throws ClassNotFoundException, SQLException {
		DBCon db = new DBCon();
		Connection con = db.dbconn();
		String s = "insert into e1 values('"+eb.getEno()+"','"+eb.getEname()+"') ";
		Statement st = con.createStatement();
		int i = st.executeUpdate(s);
		if(i!=0) {
			return true;
		}
		return false;
	}
	
	public boolean empDelete(EmployeeBean eb) throws ClassNotFoundException, SQLException {
		DBCon db = new DBCon();
		Connection con = db.dbconn();
		String s2 = "delete from e1 where eno="+eb.getEno();
		Statement st = con.createStatement();
		int i = st.executeUpdate(s2);
		if(i!=0) {
			return true;
		}
		return false;
	}
	
	public boolean empUpdate(EmployeeBean eb) throws ClassNotFoundException, SQLException {
		DBCon db = new DBCon();
		Connection con = db.dbconn();
		String s3 = "update e1 set ename='"+eb.getEname()+"' where eno="+eb.getEno();
		Statement st = con.createStatement();
		int i = st.executeUpdate(s3);
		if(i!=0) {
			return true;
		}
		return false;
	}

}
